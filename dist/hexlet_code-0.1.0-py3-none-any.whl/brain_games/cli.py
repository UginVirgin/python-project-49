def welcome_user():
    name = input("Введите свое имя: ")
    print(f"Приятно познакомиться, {name}")